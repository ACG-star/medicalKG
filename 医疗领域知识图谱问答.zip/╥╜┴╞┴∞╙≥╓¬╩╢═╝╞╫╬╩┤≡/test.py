"""
@File    :   test.py    
@Contact :   xwz3568@163.com

@Modify Time          @Author    @Version    @Description
------------          --------   --------    -----------
2023/9/9 0009 16:29  FuGui      1.0         KG_test
"""


# import os


# cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])  # 加载文件路径
# abspath("")函数，传入一个空/字符串，获取当前绝对路径/+传入的字符串
# __file__=str 'F:\\毕业设计\\知识图谱参考资料\\医疗知识图谱资料\\05医疗知识图谱问答机器人\\QAMedicalKG\\test.py'
# __file__ 内置的变量，它表示当前文件的文件名
# print(os.path.abspath('X').split('\\')[:-1])
# "字符串".join([列表]/（元组）)，使用指定的字符拼接字符序列，即将列表组合成字符串
# example：'-'.join(['A','B','C'])  -->  'A-B-C'
# os.path.abspath(__file__).split('\\')[:-1]) # 散着的列表
# os.path.abspath(__file__)=F:\毕业设计\知识图谱参考资料\医疗知识图谱资料\05医疗知识图谱问答机器人\QAMedicalKG\test.py



#
# cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])  # 加载文件路径
# department_path = os.path.join(cur_dir, 'dict/department.txt')
# department_wds = [i.strip() for i in open(department_path, encoding="utf-8") if i.strip()]
# print()
# print(department_wds)
# print()
#
#
#
# department_wd = [i.strip() for i in open(department_path, encoding="utf-8") if i.strip()]
'''
列表推导式
一般是[操作 循环]结构，语义：对循环内所有元素都做某一操作
对于这个推导式：
[对每一行做的操作   循环文件内的每一行数据    如果有数据则做操作，否则进行下一次循环]

在 Python 的条件判断中，以下值被视为假：
False：布尔类型的假值
None：表示空值或缺失值
0：整数类型的零值
0.0：浮点类型的零值
''（空字符串）：字符串类型的空值
[]（空列表）：列表类型的空值
{}（空字典）：字典类型的空值
()（空元组）：元组类型的空值
'''

#
# def build_entitydict(args):
#     entity_dict = {}
#     for arg, types in args.items():
#         for type in types:
#             if type not in entity_dict:
#                 entity_dict[type] = [arg]
#             else:
#                 entity_dict[type].append(arg)
#     return entity_dict
#
# dict_test = {'咳嗽'}
# build_entitydict()




# region_wds = ['咳嗽','咳嗽','肝硬化','咳','硬化']  # 尝试能否做到简单的去重
# stop_wds = []
# for wd1 in region_wds:  # 从列表中拿出两个依次比较，出现雷同的将雷同的短词加入停用词表
#     for wd2 in region_wds:
#         if wd1 in wd2 and wd1 != wd2:
#             stop_wds.append(wd1)
# final_wds = list(set([i for i in region_wds if i not in stop_wds]))
# print(stop_wds)
# print(final_wds)


import json

for datas in open('data/medical2.json'):
    data = json.loads(datas)
    print(data)
    break






