class QuestionPaser:
    # 构建实体节点
    # 为分类后的关键词及类别构建节点
    def build_entitydict(self, args):
        entity_dict = {}  # {type：[word1,word2],type2……}
        for arg, types in args.items():
            for type in types:
                # 将类别做键，关键词做值 列表(存在有多个关键词隶属于一个类别)，如果该类别第一次出现则创建新的键值对，否则向值列表添加关键词
                if type not in entity_dict:
                    entity_dict[type] = [arg]
                else:
                    entity_dict[type].append(arg)
        return entity_dict
    '''
    data构成：
        data={
            'args' : {问句关键词1:关键词类别1，
                    问句关键词2:关键词类别2，………},
            'question_types'  : [问句类型1，问句类型2，……]
        }
    '''

    '''解析主函数'''

    def parser_main(self, res_classify):
        args = res_classify['args']  # 取出data中的关键词及关键词类别
        entity_dict = self.build_entitydict(args)  # 调用上面的构造实体节点函数
        # entity_dict构成 {疾病类型1：['关键词1', '关键词2']}
        question_types = res_classify['question_types']  # 需要question_classifier.py完成问题类型的识别
        # question_types  [问句类型1，问句类型2，……]
        sqls = []
        for question_type in question_types:
            sql_ = {}  # 注意与下面sql的区别
            sql_['question_type'] = question_type  # 取一个类型-循环取，sql_字典内永远只有一个键值对
            sql = []
            # 根据不同的问句型做不同的操作
            if question_type == 'disease_symptom':  # 疾病症状——给出疾病详细信息
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))  # sql_transfer是下面定义的分开处理问题子函数
            # 对不同的问句做不同的cql查询
            elif question_type == 'symptom_disease':  # 症状——给出症状描述
                sql = self.sql_transfer(question_type, entity_dict.get('symptom'))

            elif question_type == 'disease_cause':  # 疾病原因-给出疾病详细信息
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_acompany':  # 疾病公司？？？
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_not_food':  # 已知疾病问 禁忌食物
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_do_food':  # 已知疾病问 宜吃食物
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'food_not_disease':  # 已知食物问 可能导致的疾病
                sql = self.sql_transfer(question_type, entity_dict.get('food'))

            elif question_type == 'food_do_disease':  # 已知食物问 预防的疾病
                sql = self.sql_transfer(question_type, entity_dict.get('food'))

            elif question_type == 'disease_drug':  # 治疗药物
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'drug_disease':  # 药物描述
                sql = self.sql_transfer(question_type, entity_dict.get('drug'))

            elif question_type == 'disease_check':  # 应该做的检查
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'check_disease':  # 可以检查出什么疾病
                sql = self.sql_transfer(question_type, entity_dict.get('check'))

            elif question_type == 'disease_prevent':  # 疾病预防
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_lasttime':  # 疾病治疗周期
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_cureway':  # 治疗方式
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_cureprob':  # 治愈可能性
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_easyget':  # 易感染人群
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            elif question_type == 'disease_desc':  # 其他情况则返回疾病描述
                sql = self.sql_transfer(question_type, entity_dict.get('disease'))

            if sql:  # 如果sql中有东西，则以字典形式写入sqls列表中
                sql_['sql'] = sql  # {sql:[]}
                sqls.append(sql_)

        return sqls  # 返回sql查询语句，可以是多条，给图谱

    '''针对不同的问题，分开进行处理'''

    def sql_transfer(self, question_type, entities):
        if not entities:
            return []

        # 查询语句
        sql = []
        # 查询疾病的原因，在debug的时候，运行到对应的elif（说明已经找到合适的关系）会自动停止该函数的执行
        if question_type == 'disease_cause':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.cause".format(i) for i in
                   entities]  # 调用match语句

        # 查询疾病的防御措施
        elif question_type == 'disease_prevent':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.prevent".format(i) for i in entities]

        # 查询疾病的持续时间
        elif question_type == 'disease_lasttime':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.cure_lasttime".format(i) for i in entities]

        # 查询疾病的治愈概率
        elif question_type == 'disease_cureprob':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.cured_prob".format(i) for i in entities]

        # 查询疾病的治疗方式
        elif question_type == 'disease_cureway':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.cure_way".format(i) for i in entities]

        # 查询疾病的易发人群
        elif question_type == 'disease_easyget':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.easy_get".format(i) for i in entities]

        # 查询疾病的相关介绍
        elif question_type == 'disease_desc':
            sql = ["MATCH (m:Disease) where m.name = '{0}' return m.name, m.desc".format(i) for i in entities]

        # 查询疾病有哪些症状
        elif question_type == 'disease_symptom':
            sql = [
                "MATCH (m:Disease)-[r:has_symptom]->(n:Symptom) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]

        # 查询症状会导致哪些疾病
        elif question_type == 'symptom_disease':
            sql = [
                "MATCH (m:Disease)-[r:has_symptom]->(n:Symptom) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]

        # 查询疾病的并发症
        elif question_type == 'disease_acompany':
            sql1 = [
                "MATCH (m:Disease)-[r:acompany_with]->(n:Disease) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql2 = [
                "MATCH (m:Disease)-[r:acompany_with]->(n:Disease) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql = sql1 + sql2

        # 查询疾病的忌口
        elif question_type == 'disease_not_food':
            sql = ["MATCH (m:Disease)-[r:no_eat]->(n:Food) where m.name = '{0}' return m.name, r.name, n.name"
                   .format(i) for i in entities]

        # 查询疾病建议吃的东西
        elif question_type == 'disease_do_food':
            sql1 = [
                "MATCH (m:Disease)-[r:do_eat]->(n:Food) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql2 = [
                "MATCH (m:Disease)-[r:recommand_eat]->(n:Food) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql = sql1 + sql2

        # 已知忌口查疾病
        elif question_type == 'food_not_disease':
            sql = ["MATCH (m:Disease)-[r:no_eat]->(n:Food) where n.name = '{0}' return m.name, r.name, n.name"
                   .format(i) for i in entities]

        # 已知推荐查疾病
        elif question_type == 'food_do_disease':
            sql1 = [
                "MATCH (m:Disease)-[r:do_eat]->(n:Food) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql2 = [
                "MATCH (m:Disease)-[r:recommand_eat]->(n:Food) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql = sql1 + sql2

        # 查询疾病常用药品－药品别名记得扩充 ##？？？
        elif question_type == 'disease_drug':
            sql1 = [
                "MATCH (m:Disease)-[r:common_drug]->(n:Drug) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql2 = [
                "MATCH (m:Disease)-[r:recommand_drug]->(n:Drug) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql = sql1 + sql2

        # 已知药品查询能够治疗的疾病
        elif question_type == 'drug_disease':
            sql1 = [  # 常用药物
                "MATCH (m:Disease)-[r:common_drug]->(n:Drug) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql2 = [  # 推荐用药
                "MATCH (m:Disease)-[r:recommand_drug]->(n:Drug) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]
            sql = sql1 + sql2
        # 查询疾病应该进行的检查
        elif question_type == 'disease_check':
            sql = [
                # entities:[类型1，类型2]
                "MATCH (m:Disease)-[r:need_check]->(n:Check) where m.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]

        # 已知检查查询疾病
        elif question_type == 'check_disease':
            sql = [
                # 根据构建图谱时的节点与关系名进行cql查询看，别看懵
                "MATCH (m:Disease)-[r:need_check]->(n:Check) where n.name = '{0}' return m.name, r.name, n.name"
                .format(i) for i in entities]

        return sql


if __name__ == '__main__':
    handler = QuestionPaser()

'''
        data构成：
        data={
            'args' : {问句关键词1:关键词类别1，
                      问句关键词2:关键词类别2，………
                      },
            'question_types'  : [问句类型1，问句类型2，……]
        }
'''
